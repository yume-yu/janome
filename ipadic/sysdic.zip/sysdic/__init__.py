import os
import sys

from janome.dic import LoadingDictionaryError

from . import chardef, connections1, connections2, unknowns

base_dir = os.path.dirname(os.path.abspath(__file__))


connections = list(connections1.DATA)
connections.extend(connections2.DATA)

__entries = None


def __add_extra_info(entries, extra_entries_info):
    for k, v in extra_entries_info.items():
        entries[k] = tuple(list(entries[k]) + list(v))


def entries(compact=False):
    global __entries
    if not __entries:
        try:
            from . import entries_compact0

            __entries = entries_compact0.DATA
            del entries_compact0.DATA

            from . import entries_compact1

            __entries.update(entries_compact1.DATA)
            del entries_compact1.DATA
            from . import entries_compact2

            __entries.update(entries_compact2.DATA)
            del entries_compact2.DATA
            from . import entries_compact3

            __entries.update(entries_compact3.DATA)
            del entries_compact3.DATA
            from . import entries_compact4

            __entries.update(entries_compact4.DATA)
            del entries_compact4.DATA
            from . import entries_compact5

            __entries.update(entries_compact5.DATA)
            del entries_compact5.DATA
            from . import entries_compact6

            __entries.update(entries_compact6.DATA)
            del entries_compact6.DATA
            from . import entries_compact7

            __entries.update(entries_compact7.DATA)
            del entries_compact7.DATA
            from . import entries_compact8

            __entries.update(entries_compact8.DATA)
            del entries_compact8.DATA
            from . import entries_compact9

            __entries.update(entries_compact9.DATA)
            del entries_compact9.DATA
        except:
            raise LoadingDictionaryError()
    if not compact and len(__entries[0]) < 5:
        # need to load extra token info
        from . import entries_extra0

        __add_extra_info(__entries, entries_extra0.DATA)
        del entries_extra0.DATA
        from . import entries_extra1

        __add_extra_info(__entries, entries_extra1.DATA)
        del entries_extra1.DATA
        from . import entries_extra2

        __add_extra_info(__entries, entries_extra2.DATA)
        del entries_extra2.DATA
        from . import entries_extra3

        __add_extra_info(__entries, entries_extra3.DATA)
        del entries_extra3.DATA
        from . import entries_extra4

        __add_extra_info(__entries, entries_extra4.DATA)
        del entries_extra4.DATA
        from . import entries_extra5

        __add_extra_info(__entries, entries_extra5.DATA)
        del entries_extra5.DATA
        from . import entries_extra6

        __add_extra_info(__entries, entries_extra6.DATA)
        del entries_extra6.DATA
        from . import entries_extra7

        __add_extra_info(__entries, entries_extra7.DATA)
        del entries_extra7.DATA
        from . import entries_extra8

        __add_extra_info(__entries, entries_extra8.DATA)
        del entries_extra8.DATA
        from . import entries_extra9

        __add_extra_info(__entries, entries_extra9.DATA)
        del entries_extra9.DATA
    return __entries


def mmap_entries(compact=False):
    import mmap
    from importlib import import_module
    from . import entries_buckets

    __mmap_entries_compact = {}
    __mmap_entries_extra = None
    __open_files = []
    for i in range(0, 10):
        bucket = entries_buckets.DATA[i]
        fp = open(os.path.join(base_dir, "entries_compact%d.py" % i), "rb")
        mm = mmap.mmap(fp.fileno(), 0, access=mmap.ACCESS_READ)
        mm_idx = import_module(".entries_compact%d_idx" % i, "sysdic")
        __open_files.append(fp)
        __mmap_entries_compact[bucket] = (mm, mm_idx.DATA)
    if not compact:
        __mmap_entries_extra = {}
        for i in range(0, 10):
            bucket = entries_buckets.DATA[i]
            fp = open(os.path.join(base_dir, "entries_extra%d.py" % i), "rb")
            mm = mmap.mmap(fp.fileno(), 0, access=mmap.ACCESS_READ)
            mm_idx = import_module(".entries_extra%d_idx" % i, "sysdic")
            __open_files.append(fp)
            __mmap_entries_extra[bucket] = (mm, mm_idx.DATA)
    return (__mmap_entries_compact, __mmap_entries_extra, __open_files)


def all_fstdata():
    import base64
    from . import fst_data0, fst_data1

    res = []
    res.append(base64.b64decode(fst_data0.DATA))
    res.append(base64.b64decode(fst_data1.DATA))
    return res
